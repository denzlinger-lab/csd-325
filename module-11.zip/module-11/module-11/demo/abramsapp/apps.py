from django.apps import AppConfig


class AbramsappConfig(AppConfig):
    name = 'abramsapp'
